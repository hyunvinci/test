A Pen created at CodePen.io. You can find this one at https://codepen.io/humbl3man/pen/CuqIl.

 Simple lightbox gallery
Responsive too (sort of)
v2.2 - add a way to pass HD versions of images to the popup
v2.1 - classes are more semantic, replaced float with flexbox (because you know its 2016)

v2 - added some responsiveness;)